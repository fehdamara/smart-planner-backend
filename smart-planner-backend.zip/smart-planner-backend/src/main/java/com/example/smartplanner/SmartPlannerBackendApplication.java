package com.example.smartplanner;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SmartPlannerBackendApplication {

	public static void main(String[] args) {SpringApplication.run(SmartPlannerBackendApplication.class, args);
	}

}
