package com.example.smartplanner.security;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SmartPlannerBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
